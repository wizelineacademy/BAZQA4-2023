
# Proyecto Automatización flujos aplicación móvil "Sauce"

El proyecto contiene una suite de pruebas automatizada del login de la aplicación Sauce. 
Realizado con Emulador Android Studio *Nota: El idioma del dispositivo fue en inglés
Implementando patrón de diseño POM con su respectiva distribución de carpetas


## Herramienta para generación de reporte

Se generan al finalizar la automatización los reportes con allure, 

## Herramienta para análisis de código estático 

Se integró pylint, para correrlo en el proyecto:
```bash
Tools | External Tools | pylint
```

## Ejecución de pruebas
Antes de ejecutar una suite de pruebas o prueba individual, ejecuta el siguiente comando para la creación de tu ambiente virtual:

```bash
pip install -r requirements.txt
```
Parametros a configurar en el runner
```bash
--tags=smoke, regression
-f
allure_behave.formatter::AllureFormatter
-o
reports/android
-f
pretty
features/
```
Edita la url en dónde se encuentra ubicado el proyecto para tomar el apk de sauce en el archivo .env, asegurate de no omitir la extensión .apk
```bash
'app': 'e:/Users/762778/Desktop/demoBehave/APP/sauce_app.apk'
```


Las credenciales del login se encuentran pre cargadas en  el archivo ".env".
Si se requiere ejecutar las pruebas de humo, se debe ejecutar en la consola el siguiente comando:
```bash
  pytest -v -m smoketests
```

Si se requiere ejecutar las pruenas de regresión, se debe ejecutar en la consola el siguiente comando
```bash
  pytest -v -m smoketests
```

Para generar un reporte allure, se debe ejecutar en consola el siguiente comando: 
```bash
  py.test --alluredir=reports ./tests
  
  allure serve reports
```
