import pytest
from appium import webdriver

DESIRED_CAPABILITIES = {
"platformName": "Android",
"platformVersion": "13",
"deviceName": "Nexus 5X",
"appName": "Swag Labs Mobile App",
"automationName": "UIAutomator2",
"appActivity": "com.swaglabsmobileapp.MainActivity",
"app": "e:/Users/762778/Desktop/demoBehave/APP/sauce_app.apk"
}

URL = "http://127.0.0.1:4723/wd/hub"

# Fixture. Define el driver.
@pytest.fixture
def driver():
    wait_seconds = 5
    driver = webdriver.Remote(URL, DESIRED_CAPABILITIES)
    driver.implicitly_wait(wait_seconds)
    yield driver
    driver.quit()


