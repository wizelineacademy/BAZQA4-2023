from behave import *
from screens.login_screen import LoginScreen
from screens.products_screen import ProductsScreen


@Given('we are in the "LOGIN" screen')
def step_impl(context):
    # Pass next to sentence
    pass


@When('we fill the "Username" label')
def step_impl(context):
    login_screen = LoginScreen(context)
    # login_screen.fill_text(*login_screen.txt_username, text='standard_user')
    login_screen.fill_text(*login_screen.txt_username, text=context.STANDARD_USER)
    # login_screen.fill_text(*login_screen.txt_username, text=LOGIN_TEXTS.get('txt_username'))


@When('we fill the "Password" label')
def step_impl(context):
    login_screen = LoginScreen(context)
    # login_screen.fill_text(*login_screen.txt_password, text='secret_sauce')
    login_screen.fill_text(*login_screen.txt_password, text=context.PASSWORD)
    # login_screen.fill_text(*login_screen.txt_password, text=LOGIN_TEXTS.get('txt_password'))


@When('we tap the "LOGIN" button')
def step_impl(context):
    login_screen = LoginScreen(context)
    login_screen.tap_element(*login_screen.btn_login)


@Then('we are in the "Products" screen')
def step_impl(context):
    products_screen = ProductsScreen(context)
    products_screen.assert_text(
        *products_screen.lbl_products, text=context.PRODUCTS)


@When('we fill the "Username Incorrect " label')
def step_impl(context):
    login_screen = LoginScreen(context)
    login_screen.fill_text(*login_screen.txt_username, text=context.USERNAME_SAUCE_USR_INC)


@When('we fill the "Password Incorrect User" label')
def step_impl(context):
    login_screen = LoginScreen(context)
    login_screen.fill_text(*login_screen.txt_username, text=context.PASSWORD_SAUCE_USR_INC)


@When('we fill the "Username Incorrect Password" label')
def step_impl(context):
    login_screen = LoginScreen(context)
    login_screen.fill_text(*login_screen.txt_username, text=context.USERNAME_SAUCE_PASS_INC)


@When('we fill the "Password Incorrect" label')
def step_impl(context):
    login_screen = LoginScreen(context)
    login_screen.fill_text(*login_screen.txt_username, text=context.PASSWORD_SAUCE_PASS_INC)


@Then('we validate message error')
def step_impl(context):
    login_screen = LoginScreen(context)
    login_screen.find_element(*login_screen.lbl_error_message)

