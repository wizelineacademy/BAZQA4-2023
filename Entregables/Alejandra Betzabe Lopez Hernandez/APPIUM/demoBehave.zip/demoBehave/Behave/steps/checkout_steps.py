from behave import *

import environment

from screens.products_screen import ProductsScreen
from screens.your_cart_screen import YourCartScreen
from screens.checkout_information_screen import CheckoutInformationScreen
from screens.checkout_overview_screen import CheckoutOverviewScreen


@Given('Given we are in "Your cart" screen')
def step_impl(context):
    environment.login(context)

    # Aggregate products
    products_screen = ProductsScreen(context)
    products_screen.tap_element(*products_screen.btn_first_item)
    products_screen.tap_element(*products_screen.btn_second_item)

    # Cart
    products_screen.tap_element(*products_screen.icon_cart)


@When('we tap on  "checkout" for continue')
def step_impl(context):
    your_cart_screen = YourCartScreen(context)
    your_cart_screen.tap_element(*your_cart_screen.btn_checkout)


@When('we fill the "Name" in checkout information screen')
def step_impl(context):
    checkout_information_screen = CheckoutInformationScreen(context)
    checkout_information_screen.fill_text(checkout_information_screen.txt_first_name_checkout, text=context.FIRST_NAME)


@When('we fill the "Last Name" in checkout information screen')
def step_impl(context):
    checkout_information_screen = CheckoutInformationScreen(context)
    checkout_information_screen.fill_text(checkout_information_screen.txt_last_name_checkout, text=context.LAST_NAME)


@When('we fill the "Zip/Postal Code" in checkout information screen')
def step_impl(context):
    checkout_information_screen = CheckoutInformationScreen(context)
    checkout_information_screen.fill_text(checkout_information_screen.txt_zip_postal_code, text=context.ZIP_POSTAL_CODE)


@When('we tap on "Continue"')
def step_impl(context):
    checkout_information_screen = CheckoutInformationScreen(context)
    checkout_information_screen.tap_element(checkout_information_screen.btn_continue_checkout)


@Then('we tap on "Finish" in checkout overview screen')
def step_impl(context):
    checkout_overview_screen = CheckoutOverviewScreen(context)
    checkout_overview_screen.tap_element(checkout_overview_screen.btn_finish_checkout)