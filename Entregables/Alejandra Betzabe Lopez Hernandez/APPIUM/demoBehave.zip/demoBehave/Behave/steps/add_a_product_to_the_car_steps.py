from behave import *

import environment

from screens.products_screen import ProductsScreen
from screens.your_cart_screen import YourCartScreen


@Given('we are in the "Products" screen')
def step_impl(context):
    environment.login(context)


@When('we tap on  "Add to cart" from the first item')
def step_impl(context):
    products_screen = ProductsScreen(context)
    products_screen.tap_element(*products_screen.btn_first_item)

    context.first_item_title = products_screen.get_text_of_element(*products_screen.lbl_title_first_item)
    context.first_item_price = products_screen.get_text_of_element(*products_screen.lbl_price_first_item)


@When('we tap on the cart icon')
def step_impl(context):
    products_screen = ProductsScreen(context)
    products_screen.tap_element(*products_screen.icon_cart)


@Then('we validate that the title is correct')
def step_impl(context):
    your_cart_screen = YourCartScreen(context)
    your_cart_screen.assert_text(*your_cart_screen.lbl_description_your_cart_first_item_cart,
                                 text=context.first_item_title)


@Then('we validate that the price is correct')
def step_impl(context):
    your_cart_screen = YourCartScreen(context)
    your_cart_screen.assert_text(*your_cart_screen.lbl_price_your_cart_first_item_cart,
                                 text=context.first_item_price)


