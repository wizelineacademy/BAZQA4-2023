from behave import *
import environment
from screens.login_screen import LoginScreen
from screens.products_screen import ProductsScreen
from screens.validate_detail_products_screen import ValidateDetailProductsScreen


@Given('we are in the "List Products" screen')
def step_impl(context):
    environment.login(context)
    products_screen = ProductsScreen(context)

    context.first_item_title_products = products_screen.get_text_of_element(*products_screen.lbl_title_first_item)
    context.first_item_price_products = products_screen.get_text_of_element(*products_screen.lbl_price_first_item)


@When('we tap on  "image" from the first item')
def step_impl(context):
    products_screen = ProductsScreen(context)
    products_screen.tap_element(*products_screen.image_product_first_item)


@Then('we validate that the title in detail is correct')
def step_impl(context):
    validate_detail_products_screen = ValidateDetailProductsScreen(context)
    validate_detail_products_screen.assert_text(*validate_detail_products_screen.lbl_detail_description,
                                                text=context.first_item_title_products)


@Then('we validate that the price in detail is correct')
def step_impl(context):
    validate_detail_products_screen = ValidateDetailProductsScreen(context)
    validate_detail_products_screen.assert_text(*validate_detail_products_screen.lbl_detail_price,
                                                text=context.first_item_price_products)








