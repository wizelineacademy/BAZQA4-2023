from behave import *

import environment
from screens.products_screen import ProductsScreen


@Given('we are in the "Products List" screen')
def step_impl(context):
    environment.login(context)


@When('we tap on  "Filter" icon')
def step_impl(context):
    products_screen = ProductsScreen(context)
    products_screen.tap_element(*products_screen.icon_filter)


@When('we tap on order by price low to high')
def step_impl(context):
    products_screen = ProductsScreen(context)
    products_screen.tap_element(*products_screen.opc_menu_filter_price_low_high)


@Then('we validate that the sort price low is correct')
def step_impl(context):
    products_screen = ProductsScreen(context)
    products_screen.assert_text(*products_screen.lbl_price_low, text=context.PRICE_LOW)


@Then('we validate that the sort price high is correct')
def step_impl(context):
    products_screen = ProductsScreen(context)
    products_screen.assert_text(*products_screen.lbl_price_high, text=context.PRICE_HIGH)