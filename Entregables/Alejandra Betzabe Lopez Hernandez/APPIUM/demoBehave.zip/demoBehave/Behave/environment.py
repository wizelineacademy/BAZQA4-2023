import subprocess
from os.path import dirname, abspath

from appium import webdriver
from dotenv import dotenv_values
from screens.login_screen import LoginScreen


def before_scenario(context, scenario):
    desired_caps = {
        'platformName': 'Android',
        'deviceName': 'Nexus 5X',
        'app': 'e:/Users/762778/Desktop/demoBehave/APP/sauce_app.apk',
        "appPackage": "com.swaglabsmobileapp",
        "appActivity": ".MainActivity"
    }

    context.driver = webdriver.Remote('http://localhost:4723/wd/hub', desired_caps)
    context.driver.implicitly_wait(10)


def login(context):
    # Login
    login_screen = LoginScreen(context)
    login_screen.fill_text(*login_screen.txt_username, text=context.STANDARD_USER)
    login_screen.fill_text(*login_screen.txt_password, text=context.PASSWORD)
    login_screen.tap_element(*login_screen.btn_login)


def after_scenario(context, scenario):
    context.driver.quit()


def context_variables(context):
    current_directory = dirname(abspath(__file__))
    data = dotenv_values(f'{current_directory}/.env')

    # LOGIN
    context.STANDARD_USER = data['STANDARD_USER']
    context.PASSWORD = data['PASSWORD']
    context.USERNAME_SAUCE_USR_INC = data['USERNAME_SAUCE_USR_INC']
    context.PASSWORD_SAUCE_USR_INC = data['PASSWORD_SAUCE_USR_INC']
    context.USERNAME_SAUCE_PASS_INC = data['USERNAME_SAUCE_PASS_INC']
    context.PASSWORD_SAUCE_PASS_INC = data['PASSWORD_SAUCE_PASS_INC']

    # PRODUCTS
    context.PRICE_LOW = data['PRICE_LOW']
    context.PRICE_HIGH = data['PRICE_HIGH']
    context.PRODUCTS = data['PRODUCTS']
    context.FIRST_NAME_CHECKOUT = data['FIRST_NAME_CHECKOUT']
    context.LAST_NAME_CHECKOUT = data['LAST_NAME_CHECKOUT']
    context.ZIP_POSTAL_CODE = data['ZIP_POSTAL_CODE']


def before_all(context):
    context_variables(context)


def after_all(context):
    subprocess.run("allure serve reports/android", shell=True)