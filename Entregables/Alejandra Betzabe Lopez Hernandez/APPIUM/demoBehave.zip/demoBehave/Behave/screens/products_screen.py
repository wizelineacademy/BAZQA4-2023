from appium.webdriver.common.appiumby import AppiumBy as By
from utils.base_actions import BaseActions


class ProductsScreen(BaseActions):
    def __init__(self, context):
        super().__init__(context.driver)
        self.lbl_products = (By.ANDROID_UIAUTOMATOR, '.text("PRODUCTS")')
        self.btn_first_item = (By.XPATH, "(//*[contains(@content-desc, 'test-ADD TO CART')])[1]")
        self.btn_second_item = (By.XPATH, "(//*[contains(@content-desc, 'test-ADD TO CART')])[1]")
        self.lbl_title_first_item = (By.XPATH, "(//*[contains(@content-desc, 'test-Item title')])[1]")
        self.icon_cart = (By.XPATH, "//*[contains(@content-desc,'test-Cart')]")
        self.lbl_price_first_item = (By.XPATH, "(//*[contains(@content-desc, 'test-Price')])[1]")
        self.image_product_first_item = (By.XPATH, "(//*[contains(@content-desc, 'test-Item')])[1]")
        self.icon_filter = (By.XPATH, "//*[contains(@content-desc,'test-Modal Selector Button')]"
                                      "/android.view.ViewGroup/android.view.ViewGroup/android.widget.ImageView")
        self.opc_menu_filter_price_low_high = (By.ANDROID_UIAUTOMATOR, '.text("Price (low to high)")')
        self.lbl_price_low = (By.XPATH, "(//*[contains(@content-desc, 'test-Price')])[1]")
        self.lbl_price_high = (By.XPATH, "(//*[contains(@content-desc, 'test-Price')])[4]")
