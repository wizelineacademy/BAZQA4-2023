from appium.webdriver.common.appiumby import AppiumBy as By
from utils.base_actions import BaseActions


class CheckoutOverviewScreen(BaseActions):
    def __init__(self, context):
        super().__init__(context.driver)
        self.btn_finish_checkout = (By.ACCESSIBILITY_ID, "test-FINISH")

