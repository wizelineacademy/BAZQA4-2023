from appium.webdriver.common.appiumby import AppiumBy as By
from utils.base_actions import BaseActions


class CheckoutInformationScreen(BaseActions):
    def __init__(self, context):
        super().__init__(context.driver)
        self.txt_first_name_checkout = (By.ACCESSIBILITY_ID, "test-First Name")
        self.txt_last_name_checkout = (By.ACCESSIBILITY_ID, "test-Last Name")
        self.txt_zip_postal_code = (By.ACCESSIBILITY_ID, "test-Zip/Postal Code")
        self.btn_continue_checkout = (By.ACCESSIBILITY_ID, "test-CONTINUE")


