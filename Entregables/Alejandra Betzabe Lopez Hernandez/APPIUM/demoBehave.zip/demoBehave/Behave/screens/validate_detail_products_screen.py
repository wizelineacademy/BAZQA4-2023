from appium.webdriver.common.appiumby import AppiumBy as By
from utils.base_actions import BaseActions


class ValidateDetailProductsScreen(BaseActions):
    def __init__(self, context):
        super().__init__(context.driver)
        self.lbl_detail_description = (By.XPATH, "//*[contains(@content-desc, 'test-Description')]"
                                                 "/android.widget.TextView[1]")
        self.lbl_detail_price = (By.ACCESSIBILITY_ID, "test-Price")
        # self.lbl_detail_price = (By.XPATH, "//*[contains(@content-desc,'test-Price')][1]")

