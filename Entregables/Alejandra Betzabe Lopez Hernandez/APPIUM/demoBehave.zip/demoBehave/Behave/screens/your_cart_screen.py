from appium.webdriver.common.appiumby import AppiumBy as By
from utils.base_actions import BaseActions


class YourCartScreen(BaseActions):
    def __init__(self, context):
        super().__init__(context.driver)
        self.lbl_description_your_cart_first_item_cart = (By.XPATH, "//*[contains(@content-desc, 'test-Description')]"
                                                                    "/android.widget.TextView[1]")
        self.lbl_price_your_cart_first_item_cart = (By.XPATH, "//*[contains(@content-desc, 'test-Price')]"
                                                              "/android.widget.TextView")
        self.btn_checkout = (By.ACCESSIBILITY_ID, "test-CHECKOUT")
        # self.btn_checkout = (By.XPATH, "//*[contains(@content-desc, 'test-CHECKOUT')]/android.widget.TextView")
