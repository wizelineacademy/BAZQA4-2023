LOGIN_TEXTS = {
    'txt_username': "standard_user",
    'txt_password': "secret_sauce"
}

